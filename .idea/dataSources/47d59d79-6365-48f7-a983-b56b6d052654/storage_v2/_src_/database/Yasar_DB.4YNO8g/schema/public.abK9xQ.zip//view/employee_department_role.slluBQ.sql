create view employee_department_role(id, name, department, role) as
SELECT e.id,
       e.name,
       d.name AS department,
       r.name AS role
FROM employees e
         LEFT JOIN departments d ON e.department_id = d.id
         LEFT JOIN roles r ON e.role_id = r.id;

alter table employee_department_role
    owner to postgres;

